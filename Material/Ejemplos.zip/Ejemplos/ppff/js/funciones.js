window.addEventListener("load", cargar);
window.addEventListener("load", cargarMaterias);
var xml = new XMLHttpRequest();


function cargar(){
    document.getElementById("btnCerrar").addEventListener("click", cerrar);
    var selCuatrimestre = document.getElementById("selCuatrimestre");
    for(var i=0;i<4;i++){
        var opt= document.createElement("option");
        opt.appendChild(document.createTextNode(i+1));
        opt.value = i+1;
        selCuatrimestre.appendChild(opt);
    }
    document.getElementById("btnModificar").addEventListener("click", modificar);
    document.getElementById("btnEliminar").addEventListener("click", eliminar);
}

function cargarMaterias(){
	if(localStorage.getItem("materias")==null){
		xml.onreadystatechange = callback;
		xml.open("GET", "http://localhost:3000/materias");
		xml.send();
	}else{
		cargarLista();
	}
}

function modificarPost(materia){
    xml.onreadystatechange = callbackModificar;
    var spinner = document.getElementById("spinner");
    xml.open("POST", "http://localhost:3000/editar");
    xml.setRequestHeader('Content-Type', 'application/json');
    xml.send(JSON.stringify(materia));
    spinner.hidden = false;
    fondo.hidden = false;
}

function eliminarPost(materia){
    xml.onreadystatechange = callbackEliminar;
    var spinner = document.getElementById("spinner");
    xml.open("POST", "http://localhost:3000/eliminar");
    xml.setRequestHeader('Content-Type', 'application/json');
    xml.send(JSON.stringify(materia));
    spinner.hidden = false;
    fondo.hidden = false;
}

function callback(){
	if(xml.readyState===4){
		if(xml.status===200){
			localStorage.setItem("materias", xml.response);
			cargarLista();
		}else{
			alert("Error del servidor"+xml.status);
		}
	}
}

function callbackEliminar(){
	if(xml.readyState===4){
		if(xml.status===200){
            if(JSON.parse(xml.response)["type"]=="ok"){
                eliminarLocalStorage(materia);
                eliminarLista(materia);
                spinner.hidden = true;
                fondo.hidden = true;
            }
		}else{
			alert("Error del servidor"+xml.status);
		}
	}
}

function callbackModificar(){
	if(xml.readyState===4){
		if(xml.status===200){
            if(JSON.parse(xml.response)["type"]=="ok"){
                modificarLocalStorage(materia);
                modificarLista(materia);
                spinner.hidden = true;
                fondo.hidden = true;
            }
		}else{
			alert("Error del servidor"+xml.status);
		}
	}
}

function cargarLista(){
    var materias = JSON.parse(localStorage.getItem("materias"));
	for(var i=0;i<materias.length;i++){
        agregarMateriaLista(materias[i]);
	}
}

function agregarMateriaLista(materia){
	tbody = document.getElementById("tbodyMaterias");
	var tr = document.createElement("tr");
	tr.setAttribute("id", materia["id"]);
	var columns = Object.keys(materia);
	for(var j=1; j < columns.length; j++){
		var cel = document.createElement("td");
		cel.setAttribute("name", columns[j]);
		var text = document.createTextNode(materia[columns[j]]);
		cel.appendChild(text);
		tr.appendChild(cel);
    }
    tr.addEventListener("dblclick", abrir);
	tbody.appendChild(tr);
}

function abrir(event){
    document.getElementById("fondoTransparente").hidden = false;
    var tr = event.target.parentElement;
    var tds = tr.childNodes;
    var materia = {};
    materia["id"]=tr.getAttribute("id");
	for(i=0; i< tds.length;i++){
		materia[tds[i].getAttribute("name")]=tds[i].innerHTML;
    }
    document.getElementById("idMateria").value = materia["id"];
    document.getElementById("inpMateria").value = materia["nombre"];
    var selCuatrimestre = document.getElementById("selCuatrimestre");
    selCuatrimestre.disabled = true;
    selCuatrimestre.value = materia["cuatrimestre"];
    if(materia["turno"]=="Mañana"){
        document.getElementById("radM").checked = true;
    }else{
        document.getElementById("radN").checked = true;
    }
    document.getElementById("inpFecha").value = getFormattedDate(materia["fechaFinal"]).split("/").join("-");
    
}

function cerrar(){
	document.getElementById("fondoTransparente").hidden = true;
	document.getElementById("inpMateria").className= "sinError";
	document.getElementById("selCuatrimestre").className= "sinError";
	document.getElementById("inpFecha").className= "sinError";
}

function modificar(){
    if(validarDatos()){
        materia = {};
        materia["id"] = document.getElementById("idMateria").value;
        materia["nombre"] = document.getElementById("inpMateria").value;
        materia["cuatrimestre"] = document.getElementById("selCuatrimestre").value;
        materia["fechaFinal"] = getFormattedDateGuardar(document.getElementById("inpFecha").value);
        var radTurno = document.getElementsByName("turno");
        for(var i=0;i<radTurno.length;i++){
            if(radTurno[i].checked){
                materia["turno"] = radTurno[i].value;
            }
        }
        modificarPost(materia);
        cerrar();
    }
}

function modificarLocalStorage(materia){
    var materias = JSON.parse(localStorage.getItem("materias"));
	for(var i=0; i<materias.length;i++){
        if(materias[i]["id"]==materia["id"]){
            materias[i]=materia;
        }
    }
    localStorage.setItem("materias", JSON.stringify(materias));
}

function modificarLista(materia){
    var tr = document.getElementById(materia["id"]);
    var tds = tr.childNodes;
    for(var i=0;i<tds.length-1;i++){
        tds[i].innerHTML = materia[tds[i].getAttribute("name")];
    }
}

function eliminar(){
    if(validarDatos()){
        materia = {};
        materia["id"] = document.getElementById("idMateria").value;
        materia["nombre"] = document.getElementById("inpMateria").value;
        materia["cuatrimestre"] = document.getElementById("selCuatrimestre").value;
        materia["fechaFinal"] = getFormattedDateGuardar(document.getElementById("inpFecha").value);
        var radTurno = document.getElementsByName("turno");
        for(var i=0;i<radTurno.length;i++){
            if(radTurno[i].checked){
                materia["turno"] = radTurno[i].value;
            }
        }
        eliminarPost(materia);
        cerrar();
    }
}

function eliminarLocalStorage(materia){
    var materias = JSON.parse(localStorage.getItem("materias"));
    var materiasEliminado = [];
	for(var i=0; i<materias.length;i++){
        if(materias[i]["id"]!=materia["id"]){
            materiasEliminado.push(materias[i]);
        }
    }
    localStorage.setItem("materias", JSON.stringify(materiasEliminado));
}

function eliminarLista(materia){
    var tr = document.getElementById(materia["id"]);
    tr.parentNode.removeChild(tr);
}

function validarDatos(){
	var nombre = document.getElementById("inpMateria");
	var turnos = document.getElementsByName("turno");
	var fecha = document.getElementById("inpFecha")

	if(nombre.value != "" && nombre.value.length>=6 && fecha.value!="" && esMayorAHoy(fecha.value)){
		return true;
	}else{
		if(nombre.value=="" || nombre.value<6){
			nombre.className = "conError";
		}else{
			nombre.className = "sinError";
        }
		if(fecha.value=="" || !esMayorAHoy(fecha.value)){
			fecha.className = "conError";
		}else{
			fecha.className = "sinError";
		}
	}
	return false;
}

function esMayorAHoy(fecha){
    var fechaAValidar = new Date(getFormattedDate(fecha));
    var fechaActual = new Date();
    return fechaAValidar>fechaActual;
}


function getFormattedDate(fecha) {
    var date = fecha.split("/");
    return date[2] + "/" + date[1] + "/" + date[0];
}

function getFormattedDateGuardar(fecha){
    var date = fecha.split("-");
    return date[2] + "/" + date[1] + "/" + date[0];
}