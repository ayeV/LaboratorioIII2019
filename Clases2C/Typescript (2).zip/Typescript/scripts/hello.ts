
let msj1:string = "hello";
console.log(msj1);


//Array
let vector:number[] = [1,2,3,4,5];

//Tupla

let tupla:[number,string] = [1,"Tuple"];

let variable:string | number | boolean;

//Enum
enum EHeroe{
    Xmen,
    Avenger
}

console.log("Enum: " + EHeroe.Avenger);
console.log('Enum: ' + EHeroe[EHeroe.Avenger]);

for(let key in EHeroe)
{
    console.log(key);
}

//funciones
let funcionEnviarMision = function(heroe:string):string
{
    return heroe+ "enviando";
}

let funcionEnviarMisionOpcional = function(heroe?:string):string
{
    return heroe+ "enviando";
}

let funcionEnviarMisionDefault = function(heroe:string = "default"):string
{
    return heroe+ "enviando";
}


console.log(funcionEnviarMision(EHeroe[EHeroe.Xmen]));


//Parametros REST

let funcionEnviarMision2 = function(...heroes:string[]):void
{
    for(let i=0;i<heroes.length;i++)
    {
        console.log(heroes[i] + " enviando");
    }
}

funcionEnviarMision2("Spiderman","Batman","Hulk");

//funcion flecha
let funcionEnviarMision3 = (heroe:string = "Heroe"):string=>{
    return heroe + "Enviando a la mision 3";
}

console.log(funcionEnviarMision3());

//tipo en el objeto
let flash:{nombre:string,edad:number,poderes:string[],getNombre:()=>string} =
{
    nombre:"Barry Allen",
    edad: 24,
    poderes:["Corre","Viaja en el tiempo"],
    getNombre(){
        return this.nombre;
    }
}

//tipo personalizado
type Heroe = {nombre:string,edad:number,poderes?:string[],getNombre:()=>string};
let ironman:Heroe = {
    nombre:"Tony Stark",
    edad:45,
    getNombre:function(){return this.nombre;}
}

console.log(ironman.getNombre());

//Interfaces
interface IHeroe{
    nombre:string,
    poder?:string,
    mostrar?():string,
}

let Wolverine:IHeroe = {
    nombre : "James"
}

console.log(Wolverine.nombre);

//Interface en clases
class Avenger implements IHeroe{
    nombre:string = "un avenger";

}

class Mutante implements IHeroe{
    nombre:string = "un mutante";

}

let unAvenger = new Avenger();
let unMutante = new Mutante();

console.log("UnAvenger : "+ unAvenger.nombre);
console.log("UnMutante : "+ unMutante.nombre);

//Interface en funcion

interface IFuncionDosNumeros{
    (num1:number,num2:number):number;
}

let miFuncion:IFuncionDosNumeros;
miFuncion = (num1,num2)=>num1+num2;

console.log(miFuncion(2,2));

//Clases
class Avenger2 implements IHeroe
{
    nombre:string = "un avenger";

    constructor(nombre:string)
    {
        this.nombre = nombre;
    }
}

let av2 = new Avenger2("Avenger 2");
console.log("Clase: " + av2.nombre);

//Clase con atrib privado
class Avenger3 {
    private _nombre:string = "un avengr";
    private _edad:number = 0;

    constructor(nombre:string)
    {
        this._nombre = nombre;
        
    }

    get edad():number{return this.edad;}
  //  set edad(e:number){this._edad = e;}

    public mostrar = ()=>this._nombre;
}

let av3 = new Avenger3("ejemplo");
console.log("Clases 2 : " + av3.mostrar());
/*av3.edad = 54;
console.log("Edad: " + av3.edad);*/

class Xmen{
    static nombre_de_clase  = "Xmen";
}

console.log("Atributo estatico de la clase: " + Xmen.nombre_de_clase);

//Herencia
class AvengerHeredado extends Avenger2
{

}

let ah = new AvengerHeredado("heredado");

//Herencia 2
class AvengerHeredado2 extends Avenger2{
    edad:number = 0;
    constructor(nombre:string,edad:number){
        super(nombre);
        this.edad = edad;
    }
}

let ah2:AvengerHeredado2 = new AvengerHeredado2("heredado4",5);

//Namespace

namespace Funciones{
   export function f1(){
        console.log("YO soy la f1");
    }

   export function f2(){
        console.log("YO soy la f2");
    }

}

Funciones.f1();
Funciones.f2();

$(function(){
    console.log("ready");
})