"use strict";
var msj1 = 2;
console.log(msj1);
