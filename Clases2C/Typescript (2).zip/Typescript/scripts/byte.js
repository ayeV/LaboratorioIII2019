"use strict";
var mensaje = "etc";
console.log(mensaje);
