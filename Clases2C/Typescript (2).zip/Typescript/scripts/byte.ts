/// <reference path="hello.ts" />

let mensaje:string = "";
console.log(mensaje);