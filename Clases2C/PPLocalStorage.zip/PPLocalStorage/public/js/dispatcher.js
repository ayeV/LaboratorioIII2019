var anuncios = [];

function traerDatos() {
    var array = localStorage.getItem('anuncios');
    if(array != null)
    {
        callback(arr);
    }
}