/// <reference path="hello.ts" />

let mensaje:string = "etc";
console.log(mensaje);