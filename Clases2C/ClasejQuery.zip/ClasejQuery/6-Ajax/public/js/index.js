$(function()
{
   $("#btnCargar").click(function(){
       //llamo a cargar
       
       var impresion_consola = function(){
           console.log(datos);
       }
   cargarDatos(impresion_consola);

   });

   $("#btnAlta").click(function(){
    //llamo a cargar
    
    var anuncio = new Anuncio("Nuevo Anuncio",
    "venta","La descripcion del nuevo anuncio","10",
    "2","3","4");

    guardarDatos(anuncio);


    }); 

    $("#btnBaja").click(function(){
        
        debugger;
        var id = datos[0].id;
    
        eliminarDatos(id);
    
    
        });
        
       $("#btnModificar").click(function(){
            var anuncio = datos[1];
            anuncio.descripcion = "nueva descripcion";

            modificar(anuncio);
       });

})

