

$(function () {
    $("#btnCargar").click(function () {
        //llamo a cargar
     
        
        cargarDatos(callbackTraerDatos);

    });

    $("#btnAlta").click(function () {
        //llamo a cargar

        var anuncio = new Anuncio("Nuevo Anuncio",
            "venta", "La descripcion del nuevo anuncio", "10",
            "2", "3", "4");

        guardarDatos(anuncio);
        refrescarTabla();
        cargarDatos(callbackTraerDatos);


    });

    $("#btnBaja").click(function () {

        var id = datos[0].id;

        eliminarDatos(id);
        refrescarTabla();
        cargarDatos(callbackTraerDatos);

    });

    $("#btnModificar").click(function () {
        var anuncio = datos[1];
        anuncio.descripcion = "nueva descripcion";

        modificar(anuncio);
        refrescarTabla();
        cargarDatos(callbackTraerDatos);
    });

})

function refrescarTabla()
{
    let div = $('#divTabla');
    div.html("");
}

function callbackTraerDatos()
{
    var x = datos.map(x => ({
        id: x.id,
        titulo : x.titulo,
        transaccion : x.transaccion,
        descripcion : x.descripcion,
        precio : x.precio,
        num_wc : x.num_wc,
        num_estacionamiento : x.num_estacionamiento,
        num_dormitorio : x.num_dormitorio
    }));
    var tabla = crearTabla(x);
    $("#divTabla").append(tabla);
    var childNodes = tabla.children();
    for(var i = 0;i<childNodes.length;i++)
    {
        childNodes[i].click(cargarForm);
    }

}

function cargarForm () {  }


function crearTabla(array) {


    var tabla = $("<table>");

    tabla.attr("class", "table");

    let cabecera = $("<tr>");
    cabecera.attr("class", "thead-dark");

    for (var atributo in array[0]) {
        let th = $("<th>");
        th.text(atributo);
        cabecera.append(th);
    }

    tabla.append(cabecera);

    for (var i in array) {
        var fila = $("<tr>");
        fila.attr("class", "row-9");
        var obj = array[i];

        for (var j in obj) {
            var celda = $("<td>");
            var dato = document.createTextNode(obj[j]);
            celda.append(dato);
            fila.append(celda);
        }
        tabla.append(fila);
    }

    return tabla;

}