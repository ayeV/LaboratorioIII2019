$(function()
{
   $("#btnCargar").click(function(){
       //llamo a cargar
       
       var impresion_consola = function(){
           console.log(datos);
       }
   cargarDatos(impresion_consola);

   });

   $("#btnAlta").click(function(){
    //llamo a cargar
    
    var anuncio = new Anuncio("titulo","descripcion","45","5","5","5","54");

    guardarDatos(anuncio);


    }); 

    $("#btnBaja").click(function(){
        //llamo a cargar
        
        var id = 4;
    
        eliminarDatos(id);
    
    
        }); 

})

