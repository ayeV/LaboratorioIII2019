function Anuncio(titulo,transaccion,descripcion,precio,num_wc,num_estacionamiento,num_dormitorio,id=null){
    if(id!=null)
    {
        this.id = id;
    }
    this.titulo = titulo;
    this.transaccion = transaccion;
    this.descripcion = descripcion;
    this.precio = precio;
    this.num_wc = num_wc;
    this.num_estacionamiento = num_estacionamiento;
    this.num_dormitorio = num_dormitorio;
    
}

var datos = [];
function cargarDatos(manejador)
{
    datos = [];

    $.getJSON("http://localhost:3000/traerAnuncios",function(resp,status)
    {
        for(var i = 0;i<resp.data.length;i++)
        {
            datos.push(new Anuncio(resp.data[i].titulo,
            resp.data[i].transaccion,resp.data[i].descripcion,resp.data[i].precio,resp.data[i].num_wc,
            resp.data[i].num_estacionamiento,resp.data[i].num_dormitorio));


        }

        if(manejador)
        {
            manejador();
        }
    });
}


function guardarDatos(datos,callback)
{
    $.post("http://localhost:3000/altaAnuncio",datos,function(data,status){
    if(callback)
    {
    //    callback();
    }
    });
}

function eliminarDatos(id,callback)
{
    $.post("http://localhost:3000/altaAnuncio","id="+id,function(data,status){
        if(callback)
        {
        //    callback();
        }
        });
}


function modificar(anuncio,callback)
{
	
	$.ajax({
		type:"POST",
		url: "",
		beforeSend:"",
		data:anuncio
	})
	.done(function(){
		if(callback)
			callback();
	})
	.fail(function(xhr,txtStatus,error){
		console.log(xhr.status + " -" + error);
	})
	.always(function(xhr)
	{
		console.log("peticion finalizada");
	})
		
	
}