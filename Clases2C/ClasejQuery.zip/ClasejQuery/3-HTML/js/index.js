$(function()
{
    $("#btnEnviar").click(function(){
        console.log($("p.rojo").text());
        console.log($("p.rojo").html());
        console.log($("#btnEnviar").val());
        console.log($("#btnEnviar").attr("id"));

    })

    $("#btnCambiar").click(function()
    {
        $("p.rojo").text("Este es el nuevo texto del parrafo rojo");
        $("p:last").html("<strong>Este parrafo va a en negrita </strong>");
        $("p:last").html(function(i,prevHTML){
            return prevHTML + "agrego mas html";
        });

        $("#btnCambiar").val("Nuevo cambio");

        $("#btnCambiar").attr("class","azul");

        $("#btnEnviar").attr({
            "class":"azul",
            "miAtributo":"miValor"
        });

        $("#btnEnviar").attr("class",function(i,prevValue){
            console.log("Clase anterior: "+ prevValue);
            return "rojo";
        });

        var boton = $("<input>").val("Nuevo boton").attr("type","button");

        $("#btnCambiar").after(boton);

        $("body").append(boton);





    })

})