$(function()
{
   $("#btnEnviar").click(function(){
       alert("hiciste click");

   })

  /* $("p.rojo").hover(function(e){
     console.log("hla");
   },
   function(e)
   {
    console.log("chau");
   }
   
   )*/

   $("p.rojo").on("click",function()
   {

   })

   $("p.rojo").on({
       "click":function(){
        console.log("hiciste click");
       },
       "mouseenter": function()
       {
        console.log("hola");
       },
       "mouseleave": function(){
        console.log("chau");
       }
   })


   $("p.rojo").off("click");
})