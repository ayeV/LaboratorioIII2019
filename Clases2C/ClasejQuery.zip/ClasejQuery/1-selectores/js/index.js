$(function()
{
    //selecciona por id
    console.log($("#btnEnviar"));

    //selecciona por tag
    consolge.log($("p"));
    
    //seleccionar por clase css
    console.log($("p.rojo"));
//selecciona por pseudoclase
    console.log($("p:last"));

    //selecciona por atributo
    console.log($("p[class=rojo]"));
})