$(function()
{
    $("#btnCambiar").click(function()
    {
      
        var boton = $("<input>").val("Nuevo boton").attr("type","button")
        .addClass("azul").css("margin","100px");

        $("body").append(boton);
        //Si la clase no esta, la asigna
        //Si la clase ya existe, la saca
        $("#btnEnviar").toggleClass("azul");
        console.log( $("input:last").css("margin"));



    });

   

})