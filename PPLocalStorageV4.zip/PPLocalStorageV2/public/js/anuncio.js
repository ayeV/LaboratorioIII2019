"use strict";
var Anuncio = /** @class */ (function () {
    function Anuncio(titulo, transaccion, descripcion, precio, num_wc, num_estacionamiento, num_dormitorio, id) {
        this._titulo = titulo;
        if (transaccion == Tipo.Alquiler)
            this._transaccion = Tipo.Alquiler;
        else
            this._transaccion = Tipo.Venta;
        this._descripcion = descripcion;
        this._precio = precio;
        this._num_wc = num_wc;
        this._num_estacionamiento = num_estacionamiento;
        this._num_dormitorio = num_dormitorio;
        //  this.active = true;
        if (id != null)
            this._id = id;
    }
    Object.defineProperty(Anuncio.prototype, "titulo", {
        get: function () { return this._titulo; },
        set: function (x) { this._titulo = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "descripcion", {
        get: function () { return this._descripcion; },
        set: function (x) { this._descripcion = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "precio", {
        get: function () { return this._precio; },
        set: function (x) { this._precio = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "id", {
        get: function () { return this._id; },
        set: function (x) { this._id = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "transaccion", {
        get: function () { return this._transaccion; },
        set: function (x) { this._transaccion = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "num_wc", {
        get: function () { return this._num_wc; },
        set: function (x) { this._num_wc = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "num_estacionamiento", {
        get: function () { return this._num_estacionamiento; },
        set: function (x) { this._num_estacionamiento = x; },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Anuncio.prototype, "num_dormitorio", {
        get: function () { return this._num_dormitorio; },
        set: function (x) { this._num_dormitorio = x; },
        enumerable: true,
        configurable: true
    });
    return Anuncio;
}());
var Tipo;
(function (Tipo) {
    Tipo[Tipo["Alquiler"] = 0] = "Alquiler";
    Tipo[Tipo["Venta"] = 1] = "Venta";
})(Tipo || (Tipo = {}));
//# sourceMappingURL=Anuncio.js.map