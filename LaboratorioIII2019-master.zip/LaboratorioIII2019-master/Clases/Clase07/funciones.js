//jquery
//selectores: 
//#, #id, #nombre
//.
// ..text, ..password

