
$(document).ready(manejadorEventos);
$(document).ready(traerDatos);


function manejadorEventos() {
    $("#btnGuardar").click(guardarAnuncio);
    $("#btnEliminar").click(eventEliminar);
    $("#btnCancelar").click(cancelar);
    $("#venta").click(filtrarV);
    $("#alquiler").click(filtrarA);
    $("#todos").click(reset);
    $("#promedioPrecio").click(mostrarPromedio);
    $('#chkId').change(function () {
        if ($(this).is(':checked')) {
            showColumn('id',true);
         }
         else {
             
            showColumn('id',false);
         }
    });
    $('#chkTitulo').change(function () {
        if ($(this).is(':checked')) {
            showColumn('titulo',true);
        } else {
            showColumn('titulo',false);
        }
    });
}

function showColumn(atributo,isShowing)
{
    debugger;
    //let td =   $('td[name ="'+atributo+'"]');
    let td = document.getElementsByName(atributo);
    if(isShowing)
    {
      for(let i = 0; i<td.length;i++)
      {
          //td[i].show();
          td[i].hidden = false;
      }
    }
    else{
        for(let i = 0; i<td.length;i++)
        {
            //td[i].show();
            td[i].hidden = true;
        }
    }
}

function mostrarPromedio() 
{
    debugger;
    var promedio = calcularPromedioPrecio();
    refrescarTabla();
    var div = document.getElementById('divTabla');

    div.appendChild(crearTablaOneColum(promedio));

}

function filtrarTitulo() 
{ 
    var anuncios = getTitulo();
    refrescarTabla();
    mostrarDatos(anuncios);
 }

function filtrarSinId() {

     refrescarTabla();
    mostrarDatos(anuncios);
}



function filtrarV() {
    debugger;
    var anuncios = filtrarVenta();
    refrescarTabla();
    mostrarDatos(anuncios);
}


function filtrarA() {
    debugger;
    var anuncios = filtrarAlquiler();
    refrescarTabla();
    mostrarDatos(anuncios);
}


function guardarAnuncio(e) {
    let data = traerDatosDelForm();

    if (guardar(data, e))
        reset();
}

function mostrarDatos(arr) {
    var div = document.getElementById('divTabla');

    div.appendChild(crearTabla(arr));

    debugger;
    let tabla = div.lastChild;
    for (var i = 0; i < tabla.childNodes.length; i++) {
        tabla.childNodes[i].addEventListener('click', cargarForm2);
    }
}



function traerDatosDelForm() {
    debugger;
    let titulo = $('#txtTitulo').val() ? $('#txtTitulo').val() : null;
    let descripcion = $('#txtDescripcion').val() ? $('#txtDescripcion').val() : null;
    let transaccion = '';
    var rdoAlquiler = document.getElementById("rdoAlquiler").checked;
    var rdoVenta = document.getElementById("rdoVenta").checked;
    if (rdoVenta)
        transaccion =  Tipo["Venta"];
    else
        transaccion =  Tipo["Alquiler"] ;
    let precio = $('#txtPrecio').val();
    let baños = $('#txtCantBaños').val();
    let estacionamientos = $('#txtCantEstacionamiento').val();
    let dormitorios = $('#txtCantDormitorio').val();
    let id = $('#txtId').val() ? $('#txtId').val():null;
    //let id = $('#txtId').val() ? $('#txtId').val(): -1 ;

    var obj = null;
    if (id == null || id == undefined || id == "") {
        if (titulo != null && descripcion != null && transaccion != null && precio != null && estacionamientos != null && dormitorios != null) {
            obj = new Anuncio(titulo, transaccion, descripcion, precio, baños, estacionamientos, dormitorios);
        }
        else {

        }
    }
    else {
        if (titulo != null && descripcion != null && transaccion != null && precio != null && estacionamientos != null && dormitorios != null) {
            obj = new Anuncio(titulo, transaccion, descripcion, precio, baños, estacionamientos, dormitorios, id);
        }
    }


    return obj;



}

function refrescarTabla() {
    let div = document.getElementById('divTabla');
    div.innerHTML = "";
}

function reset() {
    document.forms[0].reset();
    refrescarTabla();
    traerDatos();
}

function cargarForm2(event) {

    debugger;
    var id =  event.target.parentElement.childNodes[7].innerHTML;

    var obj = getAnuncioById(id);

    var anuncio = new Anuncio(obj.titulo,obj.transaccion,obj.descripcion,obj.precio,obj.num_wc,obj.num_estacionamiento,obj.num_dormitorio,obj.id);

    $("#txtId").val(anuncio.id);
    $("#txtTitulo").val(anuncio.titulo);
    $("#txtDescripcion").val(anuncio.descripcion);
    var rdoAlquiler = document.getElementById("rdoAlquiler");
    var rdoVenta = document.getElementById("rdoVenta");
    if (anuncio.transaccion.toLowerCase() == 'alquiler')
        rdoAlquiler.checked = true;
    else
        rdoVenta.checked = true;
    $("#txtPrecio").val(anuncio.precio);
    $("#txtCantBaños").val(anuncio.num_wc);
    $("#txtCantEstacionamiento").val(anuncio.num_estacionamiento);
    $("#txtCantDormitorio").val(anuncio.num_dormitorio);


}

function cargarForm(event,id) {

    debugger;
    var tr = event.target.parentElement;
    var tds = tr.childNodes;
    var anuncio = {};

    anuncio.titulo = tds[0].innerHTML;
    anuncio.transaccion = tds[1].innerHTML;
    anuncio.descripcion = tds[2].innerHTML;
    anuncio.precio = tds[3].innerHTML.replace('$', '').split(',').join("");
    anuncio.num_wc = tds[4].innerHTML;
    anuncio.num_estacionamiento = tds[5].innerHTML;
    anuncio.num_dormitorio = tds[6].innerHTML;
    anuncio.id = tds[7].innerHTML;

    $("#txtId").val(anuncio.id);
    $("#txtTitulo").val(anuncio.titulo);
    $("#txtDescripcion").val(anuncio.descripcion);
    var rdoAlquiler = document.getElementById("rdoAlquiler");
    var rdoVenta = document.getElementById("rdoVenta");
    if (anuncio.transaccion.toLowerCase() == 'alquiler')
        rdoAlquiler.checked = true;
    else
        rdoVenta.checked = true;
    $("#txtPrecio").val(anuncio.precio);
    $("#txtCantBaños").val(anuncio.num_wc);
    $("#txtCantEstacionamiento").val(anuncio.num_estacionamiento);
    $("#txtCantDormitorio").val(anuncio.num_dormitorio);


}


function cancelar() {
    var form = document.getElementById("divAnuncio");
    form.reset();
}

function eventEliminar(e) {
    let data = traerDatosDelForm();
    eliminar(data, e);
    reset();

}
