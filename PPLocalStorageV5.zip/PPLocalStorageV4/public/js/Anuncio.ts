class Anuncio implements IEtc{
    private _titulo: string;
    private _descripcion: string;
    private _precio: number;
    private _id?: number;
    private _transaccion: Tipo;
    private _num_wc: number;
    private _num_estacionamiento: number;
    private _num_dormitorio: number;


    constructor(titulo: string, transaccion: string, descripcion: string, precio: number, num_wc: number, num_estacionamiento: number, num_dormitorio: number, id?:number) {
        this._titulo = titulo;
        if(transaccion.toLocaleLowerCase() == 'alquiler')
            this._transaccion = Tipo.Alquiler;
        else
            this._transaccion = Tipo.Venta;
        this._descripcion = descripcion;
        this._precio = precio;
        this._num_wc = num_wc;
        this._num_estacionamiento = num_estacionamiento;
        this._num_dormitorio = num_dormitorio;
        //  this.active = true;
        if (id != null)
            this._id = id;

    }

    get titulo(): string { return this._titulo; }
    set titulo(x:string){this._titulo = x;}

    get descripcion() :string{return this._descripcion;}
    set descripcion(x:string){this._descripcion = x;}

    get precio():number{return this._precio;}
    set precio(x:number){this._precio = x;}

    get id():any {return this._id;}
    set id(x:any){this._id = x;}

    get transaccion():Tipo{return this._transaccion;}
    set transaccion(x:Tipo){this._transaccion = x;}

    get num_wc():number{return this._num_wc;}
    set num_wc(x:number){this._num_wc = x;}

    get num_estacionamiento():number{return this._num_estacionamiento;}
    set num_estacionamiento(x:number){this._num_estacionamiento = x;}

    get num_dormitorio():number{return this._num_dormitorio;}
    set num_dormitorio(x:number){this._num_dormitorio = x;}

  
    
}

enum Tipo{
    Alquiler= "alquiler",
    Venta = "venta"
}

interface IEtc{

}