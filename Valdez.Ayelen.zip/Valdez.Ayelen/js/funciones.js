//Shift+alt+f dar formato al documento

window.onload = events;
httpReq = new XMLHttpRequest();
function events() {
    // var btnLoad = document.getElementById("btnLoad").addEventListener("click", loadPerson);
    var btnShow = document.getElementById("mostrar").addEventListener("click", showAddPerson);
    pedirMateriasGet();
   
    
}


function callback() {
    if (httpReq.readyState == 4) {
        if (httpReq.status == 200) {

            //httpReq.send(JSON.stringify(personas));
            loadList();

        }

    }
}

function loadList() {
    //  var materias = JSON.parse(localStorage.getItem("materias")); //esto en mi casa funciona, en la fac no.
    var personas = JSON.parse(httpReq.response); //en mi casa no funciona, en la facultad si
    var count = personas.length;

    var tbody = document.getElementById("tablaResultados");
    for (var i = 0; i < count; i++) {
        var nTr = document.createElement("tr");

        var nTdNombre = document.createElement("td");
        var nTdCuatrimestre = document.createElement("td");
        var nTdFecha = document.createElement("td");
        var nTdId = document.createElement("td");
        var nTdTurno = document.createElement("td");
        var nTdActionDelete = document.createElement("td");
        var nTdActionM = document.createElement("td");
        //var actionModified = document.createElement("a");
        //  var txtModified = texto = document.createTextNode("modificar");
        //  var actionDelete = document.createElement("a");
        //var txtDelete = texto = document.createTextNode("borrar");
        nTr.appendChild(nTdNombre);
        nTr.appendChild(nTdCuatrimestre);
        nTr.appendChild(nTdFecha);
        nTr.appendChild(nTdTurno);
        //nTr.appendChild(nTdActionDelete);
        nTr.appendChild(nTdId);
        //nTr.appendChild(nTdActionM);
        var txtNombre = texto = document.createTextNode(personas[i].nombre);
        var txtCuatri = texto = document.createTextNode(personas[i].cuatrimestre);
        var txtTurno = texto = document.createTextNode(personas[i].turno);
        var txtFecha = texto = document.createTextNode(personas[i].fechaFinal);

        nTdNombre.appendChild(txtNombre);
        nTdCuatrimestre.appendChild(txtCuatri);
        nTdFecha.appendChild(txtFecha);
        nTdTurno.appendChild(txtTurno);
        //  nTdActionDelete.appendChild(actionDelete);
        // nTdActionM.appendChild(actionModified);
        /* actionDelete.appendChild(txtDelete);
         actionDelete.setAttribute("href", '');
         actionDelete.addEventListener("click",borrar);
         actionModified.addEventListener("click",modificar);
         actionModified.appendChild(txtModified);
         actionModified.setAttribute("href", '');
         actionModified.addEventListener("click", editar);*/
         debugger;
         nTr.addEventListener("ondblclick",loadMateria);
         
        tbody.appendChild(nTr);

    }


}

function addRowHandlers() {
    debugger;
    var oRows = document.getElementById('tablaResultados').getElementsByTagName('tr');
    var iRowCount = oRows.length;
    for (i = 1; i < iRowCount; i++) {
        oRows = table.iRowCount[i];
       oRows.addEventListener("ondblclick",loadMateria);
    }
}



function ajax(metodo, url, parametros, tipo) {
    httpReq.onreadystatechange = callback;

    if (metodo === "GET") {

        httpReq.open("GET", url, tipo); //abre la conexión con el servidor
        httpReq.send();
    }
    else {
        httpReq.open("POST", url, tipo); //abre la conexión con el servidor
        httpReq.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); //string
        httpReq.send(parametros);
    }
}

function pedirMateriasGet() {
    if (localStorage.getItem("materias") === null) {
        ajax("GET", "http://localhost:3000/materias", "", true);
    }
    else {
        loadList();
    }
}


function showAddPerson() {

    var claseActual = document.getElementById("divCargarPersona").className;

    if (claseActual == "cargarPersona cargarPersonaOculto") {
        document.getElementById("divCargarPersona").className = "cargarPersona cargarPersonaVisible";
    }
    else {
        document.getElementById("divCargarPersona").className = "cargarPersona cargarPersonaOculto";
    }
}


function loadMateria() {
    var materias = JSON.parse(localStorage.getItem("materias"));
    var nombre = document.getElementById("nombre").value;
    var cuatri = document.getElementById("cuatrimestre");
    var strCuatri = cuatri.options[cuatri.selectedIndex].value;
    if (document.getElementById('turnom').checked) {
        rate_value = document.getElementById('turnom').value;
    }
    if (document.getElementById('turnon').checked) {
        rate_value = document.getElementById('turnon').value;
    }

    var fecha = document.getElementById("fecha").value;
    var materiaStr = '{"nombre":"' + nombre + '","apellido":"' + apellido + '","telefono":"' + telefono + '","fecha":"' + fecha + '"}'
    var materiaObj = JSON.parse(personaStr);
    materias.push(materiaObj);
    localStorage.setItem("materias", JSON.stringify(materias));


}


function deletePerson(id) {
    var materias = JSON.parse(localStorage.getItem("materias"));
    delete materias[id];
    localStorage.setItem("materias", JSON.stringify(materias));
}


function borrar(event) {
    event.preventDefault();
    var targ = event.target;
    var tr = targ.parentNode.parentNode;
    var child = tr.children;
    var materia = {};
    for (i = 0; i < children.length - 1; i++) {
        materia[children[i].getAttribute("name")] = tds[i].innerHTML;
    }
    borrar(tr.getAttribute("id"));
    tr.parentNode.removeChild(tr);

}

function modificar(indicePersona, event) {
    event.preventDefault();
    /*  var personas = JSON.parse(localStorage.getItem("personas"));
      personas.splice(indicePersona, 1);*/

}


function editar(i) {
    var personas = JSON.parse(localStorage.getItem("personas"))[i];
    document.getElementById("nombre").value = personas.nombre;
    document.getElementById("apellido").value = personas.apellido;
    document.getElementById("telefono").value = personas.telefono;
    document.getElementById("fecha").value = personas.fecha;
    document.getElementById("divCargarPersona").className = "cargarPersona cargarPersonaVisible";
}
