
$(document).ready(function () {
    var $loading = $('#spinner').hide();
    var $background = $('#background').hide();

        
    $(document)
        .ajaxStart(function () {
            $loading.show();
            $background.show();

        })
        .ajaxStop(function () {
            $loading.hide();
            $background.hide();

        });
    pedirPersonajesGet();

});



function loadList(personajes) {
    var count = personajes.length;
    var tbody = document.getElementById("tablaResultados");
    for (var i = 0; i < count; i++) {
        var nTr = document.createElement("tr");

        var nTdImg = document.createElement("td");
        var btnFile = document.createElement("INPUT");
        btnFile.setAttribute("type", "file");
        btnFile.id = "btnFile";
        nTdImg.appendChild(btnFile);

        var img = document.createElement('img');
        img.id = "img";
        img.src = personajes[i].foto;

        var nTdNombre = document.createElement("td");
        var nTdApellido = document.createElement("td");
        var nTdEstado = document.createElement("td");

        var selectList = document.createElement("select");
        selectList.id = "estado";
        var option1 = document.createElement("option");
        option1.value = "Vivo";
        option1.text = personajes[i].estado;
        var option2 = document.createElement("option");
        if (personajes[i].estado == "Vivo") {
            option2.value = "Muerto";
            option2.text = "Muerto";
        }
        else {
            option2.value = "Vivo";
            option2.text = "Vivo";
        }

        selectList.appendChild(option1);
        selectList.appendChild(option2);

        nTdEstado.appendChild(selectList);

        var nTdID = document.createElement("td");
        nTdID.setAttribute("style", "display:none");
        nTr.setAttribute("id", personajes[i].id);

        var textimg = document.createElement("td");
        textimg.setAttribute("style", "display:none");
        nTr.setAttribute("foto", personajes[i].foto);

        nTr.appendChild(nTdImg);
        nTr.appendChild(nTdNombre);
        nTr.appendChild(nTdApellido);
        nTr.appendChild(nTdEstado);
        nTr.appendChild(nTdID);
        nTr.appendChild(textimg);

        var txtNombre = texto = document.createTextNode(personajes[i].nombre);
        var txtApellido = texto = document.createTextNode(personajes[i].apellido);


        var id = texto = document.createTextNode(personajes[i].id);
        var txtImg = texto = document.createTextNode(personajes[i].foto);

        nTdImg.appendChild(img);
        nTdNombre.appendChild(txtNombre);
        nTdApellido.appendChild(txtApellido);
        nTdEstado.appendChild(selectList);
        nTdID.appendChild(id);
        textimg.appendChild(txtImg);

       $("#btnFile").change(function (e) {
            if (this.files && this.files[0]) {
                var target = e.currentTarget;
                var tr = target.parentNode.parentNode;
                var idPersonaje = tr.cells[4].innerText;
                var foto = tr.cells[5].innerText;
                
                var fReader = new FileReader();

                fReader.addEventListener("load", function (e) {
                    
                    var obj = { id: idPersonaje, foto:foto };
                    $.post("http://localhost:3000/editarFoto", obj,
                        function (data, status) {
                            $("#img").attr("src", e.target.result);
                            debugger;
                            var row = document.getElementById(idPersonaje);
                            var tds = row.childNodes;
                            $("#img").src = e.target.result;
                         
                            
                        });
                });

                fReader.readAsDataURL(this.files[0]);
            }
        });
        tbody.appendChild(nTr);

    }


}

function modificar()
{
    debugger;
    if (this.files && this.files[0]) {
        var idPersonaje = $("#id").val();;
        var foto = $("#foto").val();
        
        var fReader = new FileReader();

        fReader.addEventListener("load", function (e) {
            
            var obj = { id: idPersonaje, foto:foto };
            $.post("http://localhost:3000/editarFoto", obj,
                function (data, status) {
                    $("#img").attr("src", e.target.result);
                    debugger;
                    var row = document.getElementById(idPersonaje);
                    var tds = row.childNodes;
                    $("#img").src = e.target.result;
                });
        });

        fReader.readAsDataURL(this.files[0]);
    }
}



function pedirPersonajesGet() {

    $.ajax({
        method: "GET",
        url: "http://localhost:3000/personajes"

    })
        .done(function (data) {
            if (data != null)
                loadList(data);
        });


}














