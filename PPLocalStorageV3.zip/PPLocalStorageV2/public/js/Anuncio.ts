class Anuncio {
    private _titulo: string;
    private _descripcion: string;
    private _precio: number;
    private _id?: number;
    private _transaccion: string;
    private _num_wc: number;
    private _num_estacionamiento: number;
    private _num_dormitorio: number;

    constructor(titulo: string, transaccion: string, descripcion: string, precio: number, num_wc: number, num_estacionamiento: number, num_dormitorio: number, id?: number) {
        this._titulo = titulo;
        this._transaccion = transaccion;
        this._descripcion = descripcion;
        this._precio = precio;
        this._num_wc = num_wc;
        this._num_estacionamiento = num_estacionamiento;
        this._num_dormitorio = num_dormitorio;
        //  this.active = true;
        if (id != null)
            this._id = id;

    }

    get titulo(): string { return this._titulo; }
    get descripcion() :string{return this._descripcion;}
    get precio():number{return this._precio;}
    get id():any {return this._id;}
    get transaccion():string{return this._transaccion;}
    get num_wc():number{return this._num_wc;}
    get num_estacionamiento():number{return this._num_estacionamiento;}
    get num_dormitorio():number{return this._num_dormitorio;}
}
