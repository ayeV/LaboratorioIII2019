var anuncios = [];

function traerDatos() {
    anuncios = [];
    var lista = JSON.parse(localStorage.getItem('anuncios'));
    if (lista != null) {
        for (var i = 0; i < lista.length; i++) {
            var obj = new Anuncio(lista[i]._titulo, lista[i]._transaccion, lista[i]._descripcion, lista[i]._precio, lista[i]._num_wc, lista[i]._num_estacionamiento, lista[i]._num_dormitorio, lista[i]._id)
            anuncios.push(obj);
        }
        anuncios = anuncios.map(obj => ({

            titulo: obj.titulo,
            transaccion: obj.transaccion,
            descripcion: obj.descripcion,
            precio: obj.precio,
            num_wc: obj.num_wc,
            num_estacionamiento: obj.num_estacionamiento,
            num_dormitorio: obj.num_dormitorio,
            id: obj.id

        }))

        mostrarDatos(anuncios);
    }

}

function getAnuncioById(id) {
    if (id != undefined) {
        for (var i = 0; i < anuncios.length; i++) {
            if (anuncios[i].id == id) {
                return anuncios[i];
            }
        }

    }
}



function guardar(data, e) {
    let success = false;

    if (data != null) {
        //Modificar
        if (data.id != undefined) {
            anuncios = anuncios.map(x => {
                if (x.id == data.id) {
                    return data;
                }
                return x;
            });

        }
        //Alta
        else {
            ;
            var id = getID(anuncios);
            data.id = id;
            anuncios.push(data);

        }
        localStorage.setItem('anuncios', JSON.stringify(anuncios));
        success = true;
    }
    else {

        alert("Debe cargar todos los datos para poder guardar un anuncio");
        e.preventDefault();

    }

}


function getID(array) {
    if (array.length == 0) {
        return 1;
    }
    else if (array.length == 1) {
        return 2;
    }
    else {
        var maxIndex = array.reduce(function (prev, curr, index) {
            if (parseInt(prev.id) > parseInt(curr.id))
                return parseInt(prev.id);
            else
                return parseInt(curr.id);
        });
        return (maxIndex + 1).toString();
    }
}

function eliminar(data, e) {

    let success = false;
    if (data != null) {
        anuncios = anuncios.filter(x => {
            return !(x.id == data.id);
        });
        localStorage.setItem('anuncios', JSON.stringify(anuncios));
        success = true;
    }
    else {
        alert("Debe seleccionar un anuncio para poder eliminarlo");
        e.preventDefault();
    }

}

function filtrarAlquiler() {

    return anuncios.filter(obj => obj.transaccion == 'alquiler')


}

function filtrarVenta() {

    return anuncios.filter(obj => obj.transaccion == 'venta')

}




function getTitulo() {
    var x = anuncios.map(obj => ({

        titulo: obj.titulo,


    }));

    return x;
}

function calcularPromedioPrecio() {
    debugger;
    let count = anuncios.length;
    //let sum = anuncios.map(x => x.precio.replace('$', '').split(',').join("")).reduce((previous, current) => current += previous);
    let sum = anuncios.reduce(function(previous, current){
        x = parseFloat(current.precio)+parseFloat(previous);
        return x;
    }, 0);
    let avg = sum / count;

    return avg;
}